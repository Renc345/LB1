﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using LR1;

namespace LR1Test
{
    [TestClass]
    public class LRTest
    {
        LR lr = new LR();
        [TestMethod]
        public void SolveTestY_03_061_09()
        {
            double a = 0.3;
            double x = 0.61;
            double b = 0.9;
            double expected = 1.02340614367165 ;

            LR Y = new LR();
            double actual = Y.Yname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestR_03_061_09()
        {
            double a = 0.3;
            double x = 0.61;
            double b = 0.9;
            double expected = 0.380689244722346;

            LR R = new LR();
            double actual = R.Rname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestY_1_minys1_0()
        {
            double a = 1;
            double x = -1;
            double b = 0;
            double expected = 1;

            LR Y = new LR();
            double actual = Y.Yname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestR_1_minys1_0()
        {
            double a = 1;
            double x = -1;
            double b = 0;
            double expected = 1;

            LR R = new LR();
            double actual = R.Rname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestY_0_1_0()
        {
            double a = 0;
            double x = 1;
            double b = 0;
            double expected = 1;

            LR Y = new LR();
            double actual = Y.Yname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestR_0_1_0()
        {
            double a = 0;
            double x = 1;
            double b = 0;
            double expected = 1;

            LR R = new LR();
            double actual = R.Rname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestY_60_1_0()
        {
            double a = 60;
            double x = 1;
            double b = 0;
            double expected = 1;

            LR Y= new LR();
            double actual = Y.Yname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestR_60_1_0()
        {
            double a = 60;
            double x = 1;
            double b = 0;
            double expected = 1;

            LR R = new LR();
            double actual = R.Rname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestY_minys1_minys1_minys1()
        {
            double a = -1;
            double x = -1;
            double b = -1;
            double expected = 1;

            LR Y = new LR();
            double actual = Y.Yname(a, x, b);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void SolveTestR_minys1_minys1_minys1()
        {
            double a = -1;
            double x = -1;
            double b = -1;
            double expected = 1;

            LR R = new LR();
            double actual = R.Rname(a, x, b);
            Assert.AreEqual(expected, actual);

        }


    }
}
