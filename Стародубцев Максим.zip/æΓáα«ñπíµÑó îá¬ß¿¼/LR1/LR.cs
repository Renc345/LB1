﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR1
{
    public class LR
    {
        public double Yname(double a, double x, double b)
        {
            double y = (Math.Pow(a,2*x) + Math.Pow(b,-x)*Math.Cos((a+b)*x))/x+1;
            return y;
         
        }
        public double Rname (double a, double x, double b)
        {
            double r = Math.Sqrt(x*x+b) - b * b * Math.Sin((a+b)/x);
            return r;
        }
    }
}
